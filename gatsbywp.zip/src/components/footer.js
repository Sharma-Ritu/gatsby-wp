import React from "react"
import "../assets/css/bootstrap.min.css"

const Footer = () => (
	<div className="container-fluid" style={{  background: `rebeccapurple` }}>
		<div style={{margin: `0 auto`,maxWidth: 960,padding: `1.45rem 1.0875rem`,}}>
			<p className="text-white text-center">Copyright @2020 Innovagesoftwares.com</p>
		</div>
	</div>
)

export default Footer;
